CREATE TABLE vehicle_images (
    id INT AUTO_INCREMENT PRIMARY KEY,

    vehicle_id INT NOT NULL,

    image_path VARCHAR(255),

    main_image BOOLEAN DEFAULT FALSE,

    FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id)
    ON DELETE CASCADE
);