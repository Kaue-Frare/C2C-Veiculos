CREATE TABLE conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,

    buyer_id INT NOT NULL,

    seller_id INT NOT NULL,

    vehicle_id INT NOT NULL,

    conversation_status ENUM(
        'active',
        'closed'
    ) DEFAULT 'active',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (buyer_id)
    REFERENCES users(id),

    FOREIGN KEY (seller_id)
    REFERENCES users(id),

    FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id)
);