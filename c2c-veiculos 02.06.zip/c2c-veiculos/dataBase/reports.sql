CREATE TABLE reports (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    vehicle_id INT,

    reason VARCHAR(255),

    description TEXT,

    report_status ENUM(
        'pending',
        'reviewing',
        'resolved'
    ) DEFAULT 'pending',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
    REFERENCES users(id),

    FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id)
);