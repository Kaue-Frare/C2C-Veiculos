CREATE TABLE plans (
    id INT AUTO_INCREMENT PRIMARY KEY,

    name VARCHAR(100),

    price DECIMAL(10,2),

    featured_ads INT,

    duration_days INT
);