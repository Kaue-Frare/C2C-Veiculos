CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,

    reviewer_id INT NOT NULL,

    reviewed_id INT NOT NULL,

    vehicle_id INT,

    rating INT CHECK (
        rating >= 1 AND rating <= 5
    ),

    comment TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (reviewer_id)
    REFERENCES users(id),

    FOREIGN KEY (reviewed_id)
    REFERENCES users(id),

    FOREIGN KEY (vehicle_id)
    REFERENCES vehicles(id)
);