CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,

    name VARCHAR(150) NOT NULL,

    email VARCHAR(150) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    cpf VARCHAR(14) UNIQUE,

    phone VARCHAR(20),

    whatsapp VARCHAR(20),

    profile_photo VARCHAR(255),

    city VARCHAR(100),

    state VARCHAR(100),

    biography TEXT,

    verified BOOLEAN DEFAULT FALSE,

    account_level ENUM(
        'common',
        'premium',
        'administrator'
    ) DEFAULT 'common',

    account_status ENUM(
        'active',
        'suspended',
        'banned'
    ) DEFAULT 'active',

    last_login TIMESTAMP NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);