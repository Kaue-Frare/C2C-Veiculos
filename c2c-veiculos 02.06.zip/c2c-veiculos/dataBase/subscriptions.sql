CREATE TABLE subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    plan_id INT NOT NULL,

    start_date DATE,

    end_date DATE,

    subscription_status ENUM(
        'active',
        'cancelled',
        'expired'
    ) DEFAULT 'active',

    FOREIGN KEY (user_id)
    REFERENCES users(id),

    FOREIGN KEY (plan_id)
    REFERENCES plans(id)
);