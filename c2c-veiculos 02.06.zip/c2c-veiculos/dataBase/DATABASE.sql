CREATE DATABASE c2c_vehicles;

USE c2c_vehicles;