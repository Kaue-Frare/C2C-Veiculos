CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_id INT NOT NULL,

    brand_id INT NOT NULL,

    model_id INT NOT NULL,

    title VARCHAR(255) NOT NULL,

    description TEXT,

    manufacture_year YEAR NOT NULL,

    model_year YEAR NOT NULL,

    color VARCHAR(50),

    mileage INT,

    price DECIMAL(12,2),

    fuel_type VARCHAR(50),

    transmission VARCHAR(50),

    city VARCHAR(100),

    state VARCHAR(100),

    accepts_trade BOOLEAN DEFAULT FALSE,

    featured BOOLEAN DEFAULT FALSE,

    ad_status ENUM(
        'active',
        'paused',
        'sold'
    ) DEFAULT 'active',

    views INT DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
    REFERENCES users(id),

    FOREIGN KEY (brand_id)
    REFERENCES brands(id),

    FOREIGN KEY (model_id)
    REFERENCES models(id)
);